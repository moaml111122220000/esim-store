// تم تقليص الكود داخل App.jsx للحفاظ على البساطة، يمكن وضع الكود الكامل لاحقًا حسب الحاجة
export default function App() {
  return (
    <div style={{ color: "white", background: "black", padding: "2rem" }}>
      <h1>ون بلس موبايل - eSIM</h1>
      <p>هذا نموذج بسيط لموقع بيع شرائح eSIM</p>
    </div>
  );
}